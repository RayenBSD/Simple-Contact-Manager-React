import React, { Component } from "react";
import "./Header.css";

class Header extends Component {
    render () {
        return (
            <header>
                <h1>Contact Manager</h1>
            </header>
        );
    }
}

export default Header;