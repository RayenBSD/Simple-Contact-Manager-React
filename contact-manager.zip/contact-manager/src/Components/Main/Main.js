import React from "react";
import { useState } from "react";
import "./Main.css";
import Contacts from "./Contacts/Contacts";

var contacts = [];

function Main () {

    const [contact, setContact] = useState("");

    function handleContact (c) {

        setContact(c.target.value);
        //console.log(contact);

    }

    function addContact () {

        contacts.push(contact);
        setContact("");
        console.log(contacts);
    }

    function getContacts () {
        let ctn = contacts.map((item, index) => <Contacts 
                                        key={index}
                                        data = {item}
                                />)

        return ctn;
        
    }
    
    return (
        <main>
            <input type="text" 
                value={contact} 
                onChange={handleContact} 
                placeholder="New contact"
            />
            <a type="button" onClick={addContact}>Set</a>   
            {getContacts()}
        </main>
    );
}

export default Main;