import React, { Component } from "react";
import "./Contacts.css";

class Contacts extends Component {

    render () {
        return (
            <div className="Contacts">
                <h3>{this.props.data}</h3>          
            </div>
        );
    }
}

export default Contacts;